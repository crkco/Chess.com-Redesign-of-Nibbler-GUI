var eval_x = 0;
var eval_y = 0;
var str = "";
var move_eval_visible = false;
var last_diff = 0;
var eval1 = 0;
var move_img = null;

function move_eval_changed() {
    let eval_node = hub.tree.node;

    if (eval_node === null || !config.show_wdl) {
        move_eval_visible = false;
        return;
    }

    while (eval_node.move === null && eval_node.parent !== null) {
        eval_node = eval_node.parent;
    }

    if (eval_node.move === null) {
        move_eval_visible = false;
        return;
    }

    move_eval_visible = true;

    let [eval_x2, eval_y2] = XY(eval_node.move.slice(2, 4));

    if (config.flip) {
        eval_x2 = 7 - eval_x2;
        eval_y2 = 7 - eval_y2;
    }

    eval_x = eval_x2 * config.square_size + config.square_size - config.square_size / 5 * 2 + config.square_size * 1 / 9;
    eval_y = eval_y2 * config.square_size - config.square_size * 1 / 9;

    if (eval_x2 === 7) {
        eval_x -= config.square_size / 3 / 2;
    }

    if (eval_y2 === 0) {
        eval_y += config.square_size / 3 / 2;
    }

    let move_eval_info_list1 = SortedMoveInfo(eval_node.parent);

    eval1 = move_eval_info_list1[0].value() * 100;

    move_img = null;
}

function draw_move_eval() {
    if (!move_eval_visible) {
        return;
    }

    let eval_node = hub.tree.node;

    if (eval_node === null) {
        return;
    }

    while (eval_node.move === null && eval_node.parent !== null) {
        eval_node = eval_node.parent;
    }

    let move_eval_info_list1 = SortedMoveInfo(eval_node.parent);
    let move_eval_info_list2 = SortedMoveInfo(eval_node);

    var winner = false;
    var diff = 0;

    str = move_eval_info_list2.length;

    if (move_eval_info_list2.length !== 1 && move_eval_info_list2.length !== 0) {
        var eval2 = 100 - move_eval_info_list2[0].value() * 100;
        
        diff = eval2 - eval1;

        if (diff > 0 || move_eval_info_list1[0].move == eval_node.move) {
            diff = 0;
        }

        diff = -1 * diff;
    } else {
        winner = true;
    }

    var best_img = new Image();
    var excellent_img = new Image();
    var good_img = new Image();
    var inaccuracy_img = new Image();
    var mistake_img = new Image();
    var blunder_img = new Image();
    var winner_img = new Image();

    best_img.src = "move_eval/images/best_256x.png";
    excellent_img.src = "move_eval/images/excellent_256x.png";
    good_img.src = "move_eval/images/good_256x.png";
    inaccuracy_img.src = "move_eval/images/inaccuracy_256x.png";
    mistake_img.src = "move_eval/images/mistake_256x.png";
    blunder_img.src = "move_eval/images/blunder_256x.png";
    winner_img.src = "move_eval/images/winner_256x.png";

    if (diff !== last_diff || move_img === null) {
        if (diff === 0) {
            move_img = best_img;
        } else if (diff <= 2) {
            move_img = excellent_img;
        } else if (diff <= 5) {
            move_img = good_img;
        } else if (diff <= 10) {
            move_img = inaccuracy_img;
        } else if (diff <= 20) {
            move_img = mistake_img;
        } else {
            move_img = blunder_img;
        }
    }

    if (winner) {
        move_img = winner_img;
    }

    last_diff = diff;

    if (move_img !== null) {
        boardctx.drawImage(move_img, eval_x, eval_y, config.square_size / 5 * 2, config.square_size / 5 * 2);
    }
    /*
    boardctx.font = "30px Arial";
    boardctx.fillStyle = "blue";

    boardctx.fillText(100 - eval1, 200, 600);
    boardctx.fillText(100 - eval2, 200, 640);
    boardctx.fillText(str, 200, 680); */
}